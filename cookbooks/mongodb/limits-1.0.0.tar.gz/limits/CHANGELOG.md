limits cookbook CHANGELOG
=========================

This file is used to list changes made in each version of the limits cookbook.

v1.0.0 (2014-12-07)
-------------------

### Breaking Changes

Cookbook has changed to be an LWRP-only usage. No longer will limits be able to be specified using attributes. Please see the readme for usage examples.

### Testing

* Perform all testing and development with ChefDK
* Add ChefSpec tests
* Add Serverspec tests

### License

* Change license from Apache to MIT

v0.2.0 (2014-04-09)
-------------------

* Initial release of limits
